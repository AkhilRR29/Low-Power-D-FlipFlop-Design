# Low Power D Flip-Flop Design

This project compares different D Flip-Flop architectures.

## Implementations
1. Conventional D Flip-Flop
2. Pulsed D Flip-Flop
3. Master-Slave D Flip-Flop
4. Reversible Gate Based D Flip-Flop

## Tools Used
LTspice – circuit simulation
Verilog – digital design
Yosys – synthesis

## Implementations

### LTspice Designs
- Master Slave DFF
- Pulsed DFF
- Reversible DFF

### Verilog Designs
- Conventional DFF
- Low Power DFF
- Reversible DFF
- 64-bit Register Implementation

## Author
Chip Designer's