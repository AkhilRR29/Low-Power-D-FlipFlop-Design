module top_conv;

reg clk;
reg [63:0] d;
wire [63:0] q;

conventional_dff U1(
    .clk(clk),
    .d(d),
    .q(q)
);

initial begin
    clk = 0;
    d = 64'hAAAAAAAAAAAAAAAA;
end

always #5 clk = ~clk;

always @(posedge clk)
    d <= d + 1;

endmodule