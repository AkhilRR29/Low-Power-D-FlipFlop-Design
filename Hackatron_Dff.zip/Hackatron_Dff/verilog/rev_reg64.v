module rev_reg64(
    input clk,
    input [63:0] d,
    output [63:0] q
);

genvar i;

generate
for(i=0;i<64;i=i+1)
begin: rev_block
    rev_dff dff_inst(
        .clk(clk),
        .d(d[i]),
        .q(q[i])
    );
end
endgenerate

endmodule