module top_low;

reg clk;
reg enable;
reg [63:0] d;

/* prevent Vivado from removing the registers */
(* keep = "true" *) wire [63:0] q;

lowpower_reg64 U1(
    .clk(clk),
    .enable(enable),
    .d(d),
    .q(q)
);

initial begin
    clk = 0;
    enable = 1;
    d = 64'hAAAAAAAAAAAAAAAA;
end

always #5 clk = ~clk;

always @(posedge clk)
    d <= d + 1;

endmodule