module tb;

reg clk;
reg enable;
reg [63:0] d;

wire [63:0] q1;
wire [63:0] q2;

conventional_dff u1(
    .clk(clk),
    .d(d),
    .q(q1)
);

lowpower_dff u2(
    .clk(clk),
    .enable(enable),
    .d(d),
    .q(q2)
);

initial begin
clk = 0;
forever #5 clk = ~clk;
end

initial begin
enable = 1;
d = 64'h0000AAAA0000AAAA;
#20 enable = 0;
#20 enable = 1;
#100 $finish;
end

endmodule