module lowpower_reg64 (
    input clk,
    input enable,
    input [63:0] d,
    output [63:0] q
);

genvar i;

generate
for(i=0;i<64;i=i+1)
begin: dff_block
    lowpower_dff dff_inst(
        .clk(clk),
        .enable(enable),
        .d(d[i]),
        .q(q[i])
    );
end
endgenerate

endmodule